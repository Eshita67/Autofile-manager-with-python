# AutoFilesManager
It checks extension of file and puts the file in its respective folder
